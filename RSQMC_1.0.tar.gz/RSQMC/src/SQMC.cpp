// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::depends(BH)]]
#include <RcppArmadillo.h>
#include <random>
#include <iostream>
#include <R.h>
#include <math.h>
#include <vector>

#include <RcppArmadilloExtensions/sample.h>

#include <boost/random/mersenne_twister.hpp>
#include <boost/math/distributions/normal.hpp>
#include <boost/math/distributions/poisson.hpp>
using boost::math::normal;

#include <boost/random.hpp>
#include <boost/random/normal_distribution.hpp>

#include "../inst/include/SamplePack/DigitalNetsBase2.h"
#include "../inst/include/Generate_RQMC.hpp"

using namespace Rcpp;


// http://thecoatlessprofessor.com/programming/set_rs_seed_in_rcpp_sequential_case/
// [[Rcpp::export]]
void set_seed(unsigned int seed) {
    Rcpp::Environment base_env("package:base");
    Rcpp::Function set_seed_r = base_env["set.seed"];
    set_seed_r(seed);
}

// [[Rcpp::export]]
arma::vec StratifiedSampling(const double n){
  // Stratified sampling over [0,1], returns n sorted uniforms
  // auto-cast in argument (from int to double)
    std::mt19937 generator(134);
    arma::vec x = arma::zeros(n);
    for(int i=0; i<n; i++){
        double a = i/n;
        double b = (i+1)/n;
        std::uniform_real_distribution<double> unif(a, b);
        x(i) = unif(generator);
    }
    return x;
}

// [[Rcpp::export]]
arma::vec Multinomial(int n, arma::vec weights){
  // Multinomial sampling 
  // Relying on the n-sorted uniforms trick (generated with stratified sampling)
    arma::vec unif = StratifiedSampling(n);
    double sum_weights = weights(0);
    int k = 0;
    arma::vec sample = arma::zeros(n);
    for(int i=0; i<n;i++){
        while (unif[i] > sum_weights){
            k++;
            sum_weights += weights[k];
        }
        sample[i] = k;
    }
    return sample;
}

// [[Rcpp::export]]
arma::vec Sample(arma::mat particles_weights, const int nb_particles, 
                 const int time){
    // Return multinomial sample
    return Multinomial(nb_particles, particles_weights.col(time));
}

// [[Rcpp::export]]
double gaussian_pdf(const double &x, const double &mu, const double &sigma){
    // Gaussian probability density function
    normal N(mu, sigma);
    return pdf(N, x);
}

arma::mat gen_sobol(const int D, const int M, Scrambled* a){
  // Generates a Sobol sequence of dimension D*M
  // The first column is sorted
  arma::mat sobol_sequence(D, M, arma::fill::zeros);
  Scrambled_Randomize(a);
  vector<double> sobol_seq;
  sobol_seq = Scrambled_GetPoints(a, D, M);
  
  for(int m=0; m<M; m++){
    for(int d=0; d<D; d++){
      sobol_sequence(d, m) = sobol_seq.at(d + D*m);
    }
  }
  return sobol_sequence;
}

// [[Rcpp::export]]
arma::vec SMC(arma::vec y, const int M, const int T){
  // Simple SMC implementation for (low dimensional) linear Gaussian model 
  
    set_seed(42);
    boost::mt19937 rng;
    
    arma::mat particles(M, T, arma::fill::zeros);
    arma::mat weights(M, T, arma::fill::zeros);
    
    // Initial particles
    for(int i=0; i<M; i++){
        particles(i,0) = R::rnorm(0, 1);
        weights(i,0) = (gaussian_pdf(y(0), particles(i,0), 1.)*
          gaussian_pdf(particles(i,0),0.,1.));
    }
    
    // Normalization
    double sum_weights = sum(weights.col(0));
    for(int i=0; i<M; i++){
        weights(i,0) /= sum_weights;
    }
    
    arma::vec x_pred(T);
    
    x_pred(0) = dot(weights.col(0), particles.col(0));
    
    for(int t=1; t<T; t++){
        arma::vec resampling = Multinomial(M, weights.col(t-1));
        
        for(int m=0; m<M; m++){
            particles(m, t) = R::rnorm(particles(resampling(m), t-1), 1.);
            weights(m,t) = gaussian_pdf(y(t), particles(m,t), 1.);
        }
        
        sum_weights = sum(weights.col(t));
        for(int m=0; m<M; m++){
            weights(m,t) /= sum_weights;
        }
        
        x_pred(t) = dot(weights.col(t), particles.col(t));
    }
    
    // Backward smoothing/sampling
    arma::mat backward_particles(M, T, arma::fill::zeros);
    arma::vec resampling = Multinomial(M, weights.col(T-1));
    
    for(int m=0; m<M; m++){
        backward_particles(m, T-1) = particles(resampling(m), T-1);
    }
    
    arma::vec wgts(M);
    
    for(int t=(T-2); t>=0; t--){
        double sum = 0;
        for(int m=0; m<M; m++){
            wgts(m) = weights(m,t)*gaussian_pdf(backward_particles(m,t+1), 
                 particles(m,t), 1.);
            sum += wgts(m);
        }
        
        for(int m=0; m<M; m++){
            wgts(m) /= sum;
        }
        
        resampling = Multinomial(M, wgts);
        
        for(int m=0; m<M; m++){
            backward_particles(m, t) = particles(resampling(m), t);
        }
    }
    arma::vec x_smooth(T);
    for(int t=0; t<T; t++){
        x_smooth[t] = mean(backward_particles.col(t));
    }
    return x_smooth;
}

// Filtre interne
// [[Rcpp::export]]
List internal_filter(const int N, arma::vec y, const int M, const int D, 
                     arma::mat Sigma, arma::mat x_prev, double sigma_y){
  // Internal filter of high dimensional linear Gaussian state space model
  // Input //
  // y : data
  // M : number of particles
  // D : dimension of data
  // Sigma : Variance-covariance matrix
  // x_prev : previous x
  // sigma_y : variance of data
  //set_seed(42);
  
  boost::mt19937 rng;
  boost::normal_distribution<double> normdist(0., 1.);
  
  // Initialize particles and weights
  arma::cube particles(M, D, N, arma::fill::zeros);
  arma::cube weights(M, D, N, arma::fill::zeros);
  arma::vec log_likelihood = arma::zeros(N);
  
  for(int n=0; n < N; n++){
    for(int m=0; m < M; m++){
      particles(m, 0, n) = 0.5 * x_prev(n, 0) + sqrt(Sigma(0, 0)) * normdist(rng);
      weights(m, 0, n) = gaussian_pdf(y(0), particles(m, 0, n), sqrt(sigma_y));
    }
    
    log_likelihood[n] = log(mean(weights.slice(n).col(0)));
    
    // Normalization
    double sum_weights = sum(weights.slice(n).col(0));
    for(int m=0; m<M; m++){
      weights(m, 0, n) /= sum_weights;
    }
    
    for(int d=1; d<D; d++){
      // Resampling
      arma::vec resampling = Multinomial(M, weights.slice(n).col(d-1));
      
      // Standard deviation
      double sd = Sigma(d, d) - pow(Sigma(d-1, d), 2)/Sigma(d-1, d-1);
      
      for(int m = 0; m < M; m++){
        double mu = (0.5*x_prev(n, d) + Sigma(d-1, d)/Sigma(d-1, d-1)*
                     (particles(resampling(m), d-1, n) - 0.5*x_prev(n, d-1)));
        
        particles(m, d, n) = sqrt(sd) * normdist(rng) + mu;
        weights(m, d, n) = gaussian_pdf(y(d), particles(m, d, n), sqrt(sigma_y));
      }
      
      log_likelihood[n] += log(mean(weights.slice(n).col(d)));
      
      sum_weights = sum(weights.slice(n).col(d));
      
      for(int m = 0; m < M; m++){
        weights(m, d, n) /= sum_weights;
      }
    }
  }
  return Rcpp::List::create(Rcpp::Named("Log_Likelihood") = log_likelihood,
                            Rcpp::Named("Particles") = particles,
                            Rcpp::Named("Weights") = weights);
}

// [[Rcpp::export]]
arma::vec resampling_QMC(int n, arma::vec weights, arma::vec sobol){
  // QMC multinomial resampling (the sobol sequence is sorted)
    double sum_weights = weights(0);
    int k = 0;
    arma::vec sample = arma::zeros(n);
    
    for(int i=0; i < n;i++){
        while (sobol(i) > sum_weights){
            k++;
            sum_weights += weights(k);
        }
        sample(i) = k;
    }
    return sample;
}

// Filtre interne (coordonnées) avec QMC
// [[Rcpp::export]]
List internal_filter_with_QMC(const int N, arma::vec y, const int M, 
                              const int D, arma::mat Sigma, arma::mat x_prev, 
                              double sigma_y){
  // Internal filter of high dimensional linear Gaussian state space model with QMC
  // Input //
  // y : data
  // M : number of particles
  // D : dimension of data
  // Sigma : Variance-covariance matrix
  // x_prev : previous x
  // sigmay_y : variance of data
  
  //set_seed(42);
  
  // Initial particles
  arma::cube particles(M, D, N, arma::fill::zeros);
  arma::cube weights(M, D, N, arma::fill::zeros);
  arma::cube particles_sorted(M, D, N, arma::fill::zeros);
  arma::vec log_likelihood = arma::zeros(N);
  
  boost::math::normal dist(0.0, 1.0);
  
  Scrambled* a;
  a = Scrambled_Create(1, 2, M);
  
  for(int n=0; n<N ; n++){
    
    arma::mat sobol_sequence = gen_sobol(2, M, a);
    
    for(int m=0; m < M; m++){
      particles(m, 0, n) = (0.5*x_prev(n, 0) + sqrt(Sigma(0,0)) * 
        quantile(dist, sobol_sequence(0, m)));
    }
    
    particles_sorted.slice(n).col(0) = sort(particles.slice(n).col(0));
    
    for(int m=0; m<M; m++){
      weights(m, 0, n) = gaussian_pdf(y(0), particles_sorted(m, 0, n), sqrt(sigma_y));
    }
    
    log_likelihood[n] = log(mean(weights.slice(n).col(0)));
    
    // Normalization
    double sum_weights = sum(weights.slice(n).col(0));
    for(int m=0; m<M; m++){
      weights(m, 0, n) /= sum_weights;
    }
    
    for(int d=1; d < D; d++){
      // Resampling step
      arma::mat sobol_sequence = gen_sobol(2, M, a);
      arma::mat sobol_sequence_transpose = sobol_sequence.t();
      arma::vec resampling = resampling_QMC(M, weights.slice(n).col(d-1), 
                                            sobol_sequence_transpose.col(0));
      
      // Mutation step
      double sd = Sigma(d, d) - pow(Sigma(d-1, d), 2)/Sigma(d-1, d-1);
      for(int m = 0; m < M; m++){
        double mu = (0.5*x_prev(n, d) + Sigma(d-1,d)/Sigma(d-1,d-1)*
                     (particles_sorted(resampling(m), d, n) - 0.5*x_prev(n, d-1)));
        particles(m, d, n) = sqrt(sd) * quantile(dist, sobol_sequence(1, m)) + mu;
      }
      
      // Weights computation
      // The particles need to be sorted for QMC to perform well
      particles_sorted.slice(n).col(d) = sort(particles.slice(n).col(d));
      for(int m = 0; m < M; m++){
        weights(m, d, n) = gaussian_pdf(y(d), particles_sorted(m, d, n), sqrt(sigma_y));
      }
      
      log_likelihood[n] += log(mean(weights.slice(n).col(d)));
      
      sum_weights = sum(weights.slice(n).col(d));
      for(int m = 0; m < M; m++){
        weights(m, d, n) /= sum_weights;
      }
    }
  }
  return Rcpp::List::create(Rcpp::Named("Log_Likelihood") = log_likelihood,
                            Rcpp::Named("Particles") = particles_sorted,
                            Rcpp::Named("Weights") = weights);
}

double poisson_pdf(const int &y, const double &x){
  // Poisson pdf 
  // Input x is the log of the mean
  boost::math::poisson P(exp(x));
  return pdf(P, y);
}


const double log2pi = std::log(2.0 * M_PI);

// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
double dmvnrm_arma(arma::vec x,  
                      arma::rowvec mean,  
                      arma::mat sigma) { 
  // Multavariate gaussian probability density function
  int xdim = x.n_rows;
  double out;
  arma::mat rooti = arma::trans(arma::inv(trimatu(arma::chol(sigma))));
  double rootisum = arma::sum(log(rooti.diag()));
  double constants = -(static_cast<double>(xdim)/2.0) * log2pi;
  
  arma::vec z = rooti * (x - arma::trans(mean)) ;    
  out = constants - 0.5 * arma::sum(z%z) + rootisum;     
  return(exp(out));
}

double mean_mat(arma::mat A){
  // Mean of a matrix (sum of all elements/number of elements)
  double out = 0.;
  for(int i=0; i<A.n_rows; i++){
    for(int j=0; j<A.n_cols; j++){
      out += A(i,j);
    }
  }
  return(out/(A.n_rows*A.n_cols));
}


// [[Rcpp::export]]
List lattice_internal_filter(const int N, const int M, const int D, 
                             arma::mat prev_external_particles, arma::mat S, 
                             arma::vec y){
  // Internal filter of high dimensional lattice model
  // const int N : number of external particles
  // const int M : number of internal particles
  // const int D : square side length
  // prev_external_particles : N*(D**2) matrix
  // arma::mat S : (D**2) * (D**2) covariance matrix 
  // y : observations, vec of dim D**2
  
  // Random gaussian generator initialisation
  
  boost::mt19937 rng;
  boost::normal_distribution<double> normdist(0., 1.);
  
  // Matrix used to store internal particles
  arma::cube internal_particles(M, D*D, N, arma::fill::zeros);

  // Matrix used to importance sampling weights
  arma::mat weights(M, D*D, arma::fill::zeros);
  
  // Likelihood vector (each coordinates corresponds to an external particle)
  arma::vec Z(N, arma::fill::zeros);
  
  // Depth of the binary tree associated with the model
  int steps = log(D*D)/log(2);

  // Runs an internal filter in the coordinates for each external particle
  for(int n=0; n<N; n++){
    
    // Extracts slice corresponding to the external particle
    arma::mat particles = internal_particles.slice(n);
    
    // Matrix we will need later to update the particles
    arma::mat updated_particles(M, D*D);
    
    // Browses the tree from the leaves 
    // k=0 corresponds to the leaves, k=steps to the root
    for(int k=0; k<=steps; k++){
      
      int d = 0 ; // component index
      
      // We browse the tree "horizontally" along the coordinates
      while(d < D*D){
        
        // Step 0 : leaves initialisation
        if(k==0){
          for(int m=0; m<M; m++){
            // mutation + weight computation
            
            particles(m, d) = prev_external_particles(n,d) + sqrt(S(d,d)) * normdist(rng);
            weights(m, d) = poisson_pdf(y[d], particles(m, d));
          }
        }
        
        // Step 1 : pair of leaves
        if(k==1){
          // Compute the resampling weights for each pair of leaves
          arma::mat v(M,M, arma::fill::zeros);
          
          arma::rowvec mu = prev_external_particles.row(n).subvec(d, d+1);
          
          for(int m1=0;m1<M; m1++){
            for(int m2=0; m2<M; m2++){
              arma::vec x = {particles(m1, d), particles(m2, d+1)};
              
              // Joint density of pair
              double joint_lh  = dmvnrm_arma(x, mu, 
                                             S.submat(arma::span(d, d+1), 
                                                      arma::span(d, d+1)));
              // Marginal density for each leaf
              double m1_lh = gaussian_pdf(particles(m1, d), 
                                          prev_external_particles(n, d), 
                                          sqrt(S(d,d)));
              
              double m2_lh = gaussian_pdf(particles(m2, d+1), 
                                          prev_external_particles(n, d+1), 
                                          sqrt(S(d+1,d+1)));
              
              // Resampling weights
              v(m1, m2) = (log(weights(m1, d)) + log(weights(m2, d+1)) + 
                log(joint_lh) - log(m1_lh) - log(m2_lh));
            }
          }
          
          v = exp(v);
          
          // Log-likelihood update
          Z(n) += log(mean_mat(v));
          
          // Vectorize weight matrix to get correct proba vector shape
          // Columns are stacked on upon another :
          //  0 1   <->   0
          //  2 3   <->   1
          //        <->   2
          //        <->   3
          arma::vec V = arma::vectorise(v);
          
          // List of all possible resampling indexes
          IntegerVector frame = seq_len(M*M)-1;
          
          // Get the output of the resampling
          IntegerVector sampled_indexes(M);

          // Same as sample function in R
          sampled_indexes = RcppArmadillo::sample(frame, M, TRUE, V);
          
          // Vector index to matrix coordinates
          // To merge the resampled couples
          // e.g. if M=3 : 
          // 0 <-> (0, 0) ; 4 <-> (1,1) ; 7 <-> (1, 2) ; 8 <-> (2, 2)
          // "%" gives the row and "/" gives the column
          for(int i=0; i<M; i++){
            int m1 = sampled_indexes(i)%M;
            int m2 = sampled_indexes(i)/M;
            
            updated_particles(i, d) = particles(m1, d);
            updated_particles(i, d+1) = particles(m2, d+1);
          }
        }
        
        
        // Step k : (2^n)-tuple of leaves
        if(k>1){
          arma::mat v(M,M, arma::fill::zeros);
          
          particles = updated_particles;
          int beg = d;
          int mid = d + pow(2, k-1);
          int end = d + pow(2, k) - 1;
          
          arma::rowvec mu_1 = prev_external_particles.row(n).subvec(beg, mid-1);
          arma::rowvec mu_2 = prev_external_particles.row(n).subvec(mid, end);
          arma::rowvec mu = prev_external_particles.row(n).subvec(beg, end);

          for(int m1=0;m1<M; m1++){
            for(int m2=0; m2<M; m2++){
              arma::vec x = arma::trans(join_rows(particles.row(m1).subvec(beg, mid-1), 
                                                  particles.row(m2).subvec(mid, end)));
              
              double joint_lh  = dmvnrm_arma(x, 
                                             mu, 
                                             S.submat(arma::span(beg, end), 
                                                      arma::span(beg, end)));
              
              double m1_lh = dmvnrm_arma(arma::trans(particles.row(m1).subvec(beg, mid-1)), 
                                         mu_1, 
                                         S.submat(arma::span(beg, mid-1), arma::span(beg, mid-1)));
              
              double m2_lh = dmvnrm_arma(arma::trans(particles.row(m2).subvec(mid, end)), 
                                         mu_2, 
                                         S.submat(arma::span(mid, end), arma::span(mid, end)));
              
              v(m1,m2) = log(joint_lh) - log(m1_lh) -log(m2_lh);
            }
          }
          
          v = exp(v);
          
          Z(n) += log(mean_mat(v));
          
          arma::vec V = arma::vectorise(v);
          
          IntegerVector frame = seq_len(M*M)-1;
          
          IntegerVector sampled_indexes(M);
          
          sampled_indexes = RcppArmadillo::sample(frame, M, TRUE, V);
          
          for(int i=0; i<M; i++){
            int m1 = sampled_indexes(i)%M;
            int m2 = sampled_indexes(i)/M;
            updated_particles.row(i).subvec(beg, mid-1) = particles.row(m1).subvec(beg, mid-1);
            updated_particles.row(i).subvec(mid, end) = particles.row(m2).subvec(mid, end);
          }
        }
        d = d+pow(2, k);
      }
    }
    internal_particles.slice(n) = updated_particles;
  }
  return Rcpp::List::create(Rcpp::Named("Log_likelihood") = Z,
                            Rcpp::Named("Particles") = internal_particles);
}


// [[Rcpp::export]]
List lattice_internal_filter_QMC(const int N, const int M, const int D, 
                             arma::mat prev_external_particles, arma::mat S, 
                             arma::vec y){
  
  // Internal filter of high dimensional lattice model
  // const int N : number of external particles
  // const int M : number of internal particles
  // const int D : square side length
  // prev_external_particles : N*(D**2) matrix
  // arma::mat S : (D**2) * (D**2) covariance matrix 
  // y : observations, vec of dim D**2
  
  // Random gaussian generator initialisation
  boost::math::normal dist(0.0, 1.0);
  
  // QMC random generator
  Scrambled* a;
  a = Scrambled_Create(1, 1, M);
  
  // Matrix used to store internal particles
  arma::cube internal_particles(M, D*D, N, arma::fill::zeros);
  
  // Matrix used to importance sampling weights
  arma::mat weights(M, D*D, arma::fill::zeros);
  
  // Likelihood vector (each coordinates corresponds to an external particle)
  arma::vec Z(N, arma::fill::zeros);
  
  // Depth of the binary tree associated with the model
  int steps = log(D*D)/log(2);
  
  // Runs an internal filter in the coordinates for each external particle
  for(int n=0; n<N; n++){
    
    // Extracts slice corresponding to the external particle
    arma::mat particles = internal_particles.slice(n);
    
    // Matrix we will need later to update the particles
    arma::mat updated_particles(M, D*D);
    
    // Browses the tree from the leaves 
    // k=0 corresponds to the leaves, k=steps to the root
    for(int k=0; k<=steps; k++){
      
      int d = 0 ; // component index
      
      // We browse the tree "horizontally" along the coordinates
      while(d < D*D){
        
        // Step 0 : leaves initialisation
        if(k==0){
          arma::mat sobol_sequence = gen_sobol(1, M, a);
          for(int m=0; m<M; m++){
            // mutation + weight computation
            particles(m, d) = (prev_external_particles(n,d) + sqrt(S(d,d)) * 
              quantile(dist, sobol_sequence(m)));
            weights(m, d) = poisson_pdf(y[d], particles(m, d));
          }
        }
        
        // Step 1 : pair of leaves
        if(k==1){
          // Compute the resampling weights for each pair of leaves
          arma::mat v(M,M, arma::fill::zeros);
          
          arma::rowvec mu = prev_external_particles.row(n).subvec(d, d+1);
          
          for(int m1=0;m1<M; m1++){
            for(int m2=0; m2<M; m2++){
              arma::vec x = {particles(m1, d), particles(m2, d+1)};
              
              // Joint density of pair
              double joint_lh  = dmvnrm_arma(x, mu, 
                                             S.submat(arma::span(d, d+1), 
                                                      arma::span(d, d+1)));
              // Marginal density for each leaf
              double m1_lh = gaussian_pdf(particles(m1, d), 
                                          prev_external_particles(n, d), 
                                          sqrt(S(d,d)));
              
              double m2_lh = gaussian_pdf(particles(m2, d+1), 
                                          prev_external_particles(n, d+1), 
                                          sqrt(S(d+1,d+1)));
              
              // Resampling weights
              v(m1, m2) = (log(weights(m1, d)) + log(weights(m2, d+1)) + 
                log(joint_lh) - log(m1_lh) - log(m2_lh));
            }
          }
          
          v = exp(v);
          
          // Log-likelihood update
          Z(n) += log(mean_mat(v));
          
          // Vectorize weight matrix to get correct proba vector shape
          // Columns are stacked on upon another :
          //  0 1   <->   0
          //  2 3   <->   1
          //        <->   2
          //        <->   3
          arma::vec V = arma::vectorise(v);
          
          // List of all possible resampling indexes
          IntegerVector frame = seq_len(M*M)-1;
          
          // Get the output of the resampling
          IntegerVector sampled_indexes(M);
          
          // Same as sample function in R
          sampled_indexes = RcppArmadillo::sample(frame, M, TRUE, V);
          
          // Vector index to matrix coordinates
          // To merge the resampled couples
          // e.g. if M=3 : 
          // 0 <-> (0, 0) ; 4 <-> (1,1) ; 7 <-> (1, 2) ; 8 <-> (2, 2)
          // "%" gives the row and "/" gives the column
          for(int i=0; i<M; i++){
            int m1 = sampled_indexes(i)%M;
            int m2 = sampled_indexes(i)/M;
            
            updated_particles(i, d) = particles(m1, d);
            updated_particles(i, d+1) = particles(m2, d+1);
          }
        }
        
        
        // Step k : (2^n)-tuple of leaves
        if(k>1){
          arma::mat v(M,M, arma::fill::zeros);
          
          particles = updated_particles;
          int beg = d;
          int mid = d + pow(2, k-1);
          int end = d + pow(2, k) - 1;
          
          arma::rowvec mu_1 = prev_external_particles.row(n).subvec(beg, mid-1);
          arma::rowvec mu_2 = prev_external_particles.row(n).subvec(mid, end);
          arma::rowvec mu = prev_external_particles.row(n).subvec(beg, end);
          
          for(int m1=0;m1<M; m1++){
            for(int m2=0; m2<M; m2++){
              arma::vec x = arma::trans(join_rows(particles.row(m1).subvec(beg, mid-1), 
                                                  particles.row(m2).subvec(mid, end)));
              
              double joint_lh  = dmvnrm_arma(x, 
                                             mu, 
                                             S.submat(arma::span(beg, end), 
                                                      arma::span(beg, end)));
              
              double m1_lh = dmvnrm_arma(arma::trans(particles.row(m1).subvec(beg, mid-1)), 
                                         mu_1, 
                                         S.submat(arma::span(beg, mid-1), arma::span(beg, mid-1)));
              
              double m2_lh = dmvnrm_arma(arma::trans(particles.row(m2).subvec(mid, end)), 
                                         mu_2, 
                                         S.submat(arma::span(mid, end), arma::span(mid, end)));
              
              v(m1,m2) = log(joint_lh) - log(m1_lh) -log(m2_lh);
            }
          }
          
          v = exp(v);
          
          Z(n) += log(mean_mat(v));
          
          arma::vec V = arma::vectorise(v);
          
          IntegerVector frame = seq_len(M*M)-1;
          
          IntegerVector sampled_indexes(M);
          
          sampled_indexes = RcppArmadillo::sample(frame, M, TRUE, V);
          
          for(int i=0; i<M; i++){
            int m1 = sampled_indexes(i)%M;
            int m2 = sampled_indexes(i)/M;
            updated_particles.row(i).subvec(beg, mid-1) = particles.row(m1).subvec(beg, mid-1);
            updated_particles.row(i).subvec(mid, end) = particles.row(m2).subvec(mid, end);
          }
        }
        d = d+pow(2, k);
      }
    }
    internal_particles.slice(n) = updated_particles;
  }
  return Rcpp::List::create(Rcpp::Named("Log_likelihood") = Z,
                            Rcpp::Named("Particles") = internal_particles);
}

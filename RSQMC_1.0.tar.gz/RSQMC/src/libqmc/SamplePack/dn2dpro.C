/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// SAMPLE PACKage                                                          //
//                                                                         //
// Example: 2D projection of a point set                                   //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// Copyright (C) 2002 by Thomas Kollig (kollig@informatik.uni-kl.de)       //
//                       Alexander Keller (keller@informatik.uni-kl.de)    //
//                                                                         //
// All rights reserved. You may not distribute this software, in whole or  //
// in part, especially not as part of any commercial product, without the  //
// express consent of the authors.                                         //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include <fstream>
using namespace std;

#include "../../../inst/include/SamplePack/DigitalNetsBase2.h"

#ifndef MAX
#define MAX(a,b) (((a)>(b))?(a):(b))
#endif

static bitvector rng32()
{
  return (bitvector)(drand48()*((double)BV_MAX+1.0));
}

typedef enum _rt
{
  rt_None,
  rt_DigitScrambled,
  rt_LinearScrambled,
  rt_Scrambled
} rt;

class Options
{
public:
  
  dgt  gtype;         // type of generator
  rt   rtype;         // randomization type
  int  d;             // net dimension
  int  d1, d2;        // projection dimensions
  int  n;             // number of points in net
  char filename[255]; // output filename
  
  Options(int argc, char **argv)
    {
      gtype = dgt_Sobol;
      rtype = rt_None;
      d = 2;
      d1 = 0;
      d2 = 1;
      n = 16;
      sprintf(filename, "dn.tex");
      for (int i = 1; i < argc; ++i)
	if (!strcmp("-dgt", argv[i]))
	  if (!strcmp("Sobol", argv[++i]))
	    gtype = dgt_Sobol;
	  else if (!strcmp("SpecialNiederreiter", argv[i]))
	    gtype = dgt_SpecialNiederreiter;
	  else if (!strcmp("NiederreiterXing", argv[i]))
	    {
	      gtype = dgt_NiederreiterXing;
	      d = atoi(argv[++i]);
	      if ((d < 4) || (d > 32))
		{
            cerr << "Only dimensions 4 to 32 are supported for NiederreiterXing" << std::endl;
		  exit(-1);
		}
	    }
	  else if (!strcmp("ShiftNet", argv[i]))
	    {
	      gtype = dgt_ShiftNet;
	      d = atoi(argv[++i]);
	      if ((d < 3) || (d > 39))
		{
            cerr << "Only dimensions 3 to 39 are supported for ShiftNet" << std::endl;
		  exit(-1);
		}
	    }
	  else
	    {
            cerr << "Unknown generator type: " << argv[i] << std::endl;
            cerr << "Possible types: Sobol, SpecialNiederreiter, NiederreiterXing dimension, ShiftNet dimension" << std::endl;
	      exit(-1);
	    }
	else if (!strcmp("-rt", argv[i]))
	  if (!strcmp("None", argv[++i]))
	    rtype = rt_None;
	  else if (!strcmp("DigitScrambled", argv[i]))
	    rtype = rt_DigitScrambled;
	  else if (!strcmp("LinearScrambled", argv[i]))
	    rtype = rt_LinearScrambled;
	  else if (!strcmp("Scrambled", argv[i]))
	    rtype = rt_Scrambled;
	  else
	    {
            cerr << "Unknown randomization type: " << argv[i] << std::endl;
            cerr << "Possible types: None, DigitScrambled, LinearScrambled, Scrambled" << std::endl;
	      exit(-1);
	    }
	else if (!strcmp("-d", argv[i]))
	  {
	    d1 = atoi(argv[++i]);
	    d2 = atoi(argv[++i]);
	    if ((d1 < 0) || (d2 < 0))
	      {
              cerr << "Projection dimensions have to be non-negative" << std::endl;
		exit(-1);
	      }
	    d = MAX(d, d1+1);
	    d = MAX(d, d2+1);
	  }
	else if (!strcmp("-n", argv[i]))
	  {
	    n = atoi(argv[++i]);
	    if (n < 1)
	      {
              cerr << "The net should have at least one point" << std::endl;
		exit(-1);
	      }
	    if (n > 16384)
	      {
              cerr << "Nets with maximal 16384 points can be printed due to LaTeX" << std::endl;
		exit(-1);
	      }
	  }
	else if (!strcmp("-o", argv[i]))
	  sprintf(filename, "%s.tex", argv[++i]);
	else if (!strcmp("-help", argv[i]))
	  {
          cout << "Usage: " << argv[0] << " [-dgt generatortype] [-rt randomizationtype] [-d dimension1 dimension2] [-n points] [-o filename]" << std::endl;
	    exit(0);
	  }
	else
	  {
          cerr << "Unknown option: " << argv[i] << std::endl;
          cerr << "Usage: " << argv[0] << " [-dgt generatortype] [-rt randomizationtype] [-d dimension1 dimension2] [-n points] [-o filename]" << std::endl;
	    exit(-1);
	  }
    }
};

/*
int main(int argc, char **argv)
{
  DigitalNetGenerator *dng = NULL;
  DigitScrambled      *ds  = NULL;
  LinearScrambled     *ls  = NULL;
  Scrambled           *os  = NULL;
  int                 i;

  Options  o(argc, argv);
  ofstream out(o.filename);
  
  switch (o.rtype)
    {
    case rt_None:
      dng = new DigitalNetGenerator(o.gtype, o.d);
      break;
    case rt_DigitScrambled:
      ds = new DigitScrambled(o.gtype, o.d, rng32);
      ds->Randomize();
      break;
    case rt_LinearScrambled:
      ls = new LinearScrambled(o.gtype, o.d, rng32);
      ls->Randomize();
      break;
    case rt_Scrambled:
      os = new Scrambled(o.gtype, o.d, o.n, rng32);
      os->Randomize();
      break;
    }
  //S.UndoGray();
  
  out << "\\documentclass[a4paper,landscape]{slides}\n"
      << "\\newif\\ifpdf\n"
      << "\\ifx\\pdfoutput\\undefined\n"
      << "  \\pdffalse\n"
      << "\\else\n"
      << "  \\pdfoutput=1\n"
      << "  \\pdfcompresslevel=9\n"
      << "  \\pdftrue\n"
      << "\\fi\n"
      << "\\ifpdf\n"
      << "\\usepackage{hyperref}\n"
      << "\\hypersetup{\n"
      << "  pdftitle={(t,m,s)-net},\n"
      << "  pdfauthor={DiscPack Version 0.1},\n"
      << "  pdfpagemode={FullScreen}\n"
      << "}\n"
      << "\\fi\n"
      << "\\begin{document}\n"
      << "\\pagestyle{empty}\n"
      << "\\begin{slide}\n"
      << "\\begin{center}\n"
      << "\\setlength{\\unitlength}{0.012cm}\n"
      << "\\begin{picture}(1000,1000)\n"
      << "\\thicklines\n"
      << "\\multiput(0,0)(1000,0){2}{\\line(0,1){1000}}\n"
      << "\\multiput(0,0)(0,1000){2}{\\line(1,0){1000}}\n";
  switch (o.rtype)
    {
    case rt_None:
      for (i = 0; i < o.n; ++i)
	{
	  out << "\\put(" << (int)((*dng)[o.d1]*1000 + 0.5) << ","
	      << (int)((*dng)[o.d2]*1000 + 0.5) << "){\\circle*{20}}\n";
	  ++(*dng);
	}
      break;
    case rt_DigitScrambled:
      for (i = 0; i < o.n; ++i)
	{
	  out << "\\put(" << (int)((*ds)[o.d1]*1000 + 0.5) << ","
	      << (int)((*ds)[o.d2]*1000 + 0.5) << "){\\circle*{20}}\n";
	  ++(*ds);
	}
      break;
    case rt_LinearScrambled:
      for (i = 0; i < o.n; ++i)
	{
	  out << "\\put(" << (int)((*ls)[o.d1]*1000 + 0.5) << ","
	      << (int)((*ls)[o.d2]*1000 + 0.5) << "){\\circle*{20}}\n";
	  ++(*ls);
	}
      break;
    case rt_Scrambled:
      for (i = 0; i < o.n; ++i)
	{
	  out << "\\put(" << (int)((*os)[o.d1]*1000 + 0.5) << ","
	      << (int)((*os)[o.d2]*1000 + 0.5) << "){\\circle*{20}}\n";
	  ++(*os);
	}
      break;
    }
  out << "\\end{picture}\n"
      << "\\end{center}\n"
      << "\\end{slide}\n"
    << "\\end{document}" << std::endl;
  out.close();
  switch (o.rtype)
    {
    case rt_None:
      delete dng;
      break;
    case rt_DigitScrambled:
      delete ds;
      break;
    case rt_LinearScrambled:
      delete ls;
      break;
    case rt_Scrambled:
      delete os;
      break;
    }
  
  return 0;
}
*/



#ifdef __cplusplus
    #include <iostream>
    #include <fstream>
    using namespace std;
#endif

int getSeed();

#include"Get_seed.hpp"

DigitalNetGenerator *DigitalNetGenerator_Create(int, int);
void DigitalNetGenerator_Destroy(DigitalNetGenerator*);
void DigitalNetGenerator_GetPoints(DigitalNetGenerator*, int, int, double*);
Scrambled*  Scrambled_Create(int, int, int);
void Scrambled_Randomize(Scrambled*);
vector<double> Scrambled_GetPoints(Scrambled*,int, int);
void HOScrambled_GetPoints(Scrambled*,int,int,int, double*);
void Scrambled_Destroy(Scrambled*);
